process.on('message', function(data) {
  try{
    var source = data.source
    var funcs = require('./' + source.src + '.js')
    var params = data.params, result
    function cb(rt){
      process.send(rt)
    }
    funcs[source.func].call(null, params, cb)
  } catch (e) {
    process.send({success:0, msg:e.message})
  }
})