let fs = require('fs')
let path = require('path')

const maxMatchTimes = 10
const maxLimit = 5;
const pathStack = [];
const excludeExtReg=/\.(jpg|jpeg|png|gif|bmp|ico|ttf|eot|woff|zip|rar|mp4)$/i;
let totalFiles = 0
let transportFiles = 0
//timeout instance
let timeInstance = null;

function doStackWork (params, cb) {
  let paths = pathStack.splice(0, maxLimit)
  if (paths.length) {
    for (let i = 0; i < paths.length; i++) {
      params.replace ? _replace(paths[i], params.reg, params.replace, cb) : _find(paths[i], params.reg, cb)
    }
  }
  if (totalFiles > transportFiles) {
    timeInstance = setTimeout(doStackWork, 3);
  }
}

function find (params,func) {
  findAction(params, func)
}

function replace (params,func) {
  findAction(params, func)
}

function findAction (params, func) {
  params.reg = new Function("return " + params.reg)()
  params.fileReg = new Function("return " + params.fileReg)()
  if (params.exclude) {
    params.exclude = new RegExp(params.exclude, 'i')
  }
  let message = []
  let sendEOF = false
  let cb = function (result) {
    transportFiles ++
    if (result) {
      message.push(result)
      if (message.length === maxLimit) {
        func({data:message, done:transportFiles})
        message = []
      }
    }else if (transportFiles % maxLimit === 0) {
      func({done:transportFiles})
    }
    // send EOF flag
    if (totalFiles === transportFiles && !sendEOF) {
      func({data:message, done:transportFiles})
      sendEOF = true
      func({EOF:true});
    }
  }
  _search(params.path, params.fileReg, params.exclude)
  doStackWork = doStackWork.bind(null, params, cb)
  setTimeout(doStackWork, 10)
}

function _search (filepath, reg, exclude) {
  fs.readdir(filepath, function (error, files) {
    if (error) {
      return
    }
    let filename  
    let newPath
    let stat
    for (let i = 0, len = files.length; i < len; i++) {
  		filename = files[i]
  		newPath = path.join(filepath, filename)
  		stat = fs.statSync(newPath)
  		//if it's the directory
      if (stat.isDirectory()) {
        if (!exclude || !exclude.test(filename)) {
          _search(newPath, reg, exclude)
        }
      } else if (!excludeExtReg.test(filename) && (!reg || reg.test(filename))) {
        pathStack.push(newPath)
        totalFiles ++
      }
  	}
  });
}

function _replace (filepath, reg, replaceCon, func) {
  fs.readFile(filepath, function (error, con) {
    if (error) {
      func(null)
      return
    }
    con = con.toString()
    let result = con.match(reg)
    if (con && result && result.length) {
      con = con.replace(reg, replaceCon);
      fs.writeFile(filepath, con, function (error) {
        if (error) {
          func(null);
        }else{
          func({count: result.length})
        }
      })
      
    } else {
      func(null)
    }
  });
}

function _find (filepath, reg, func) {
  fs.readFile(filepath, function (error, con) {
    if (error) {
      func(null)
      return
    }
    con = con.toString()
    let result = con.match(reg)
    let count = result ? result.length : 0
    if (con && count) {
      let lines = getLinePos(con)
      let match = []
      let times = 0
      let currentRow = -1
      do {
        result = reg.exec(con)
        if (result) {
          let index = result.index
          let row = mapLineByNumber(lines, index)
          // 如果当前行相同，返回
          if (row === currentRow) {
            continue
          }
          currentRow = row
          let start = 0
          // get start position
          if (lines.length > 2) {
            start = lines[row - 2] + 1
          }
          if (index - start > 50) {
            start = index - 50
            index = index + result[0].length
          } else {
            index = start + 100
            if (index > lines[row - 1]) {
              index = lines[row - 1]
            }
          }
          let line = con.slice(start, index)
          line = line.trim()
          match.push({row, line})
        }
        times ++
      } while (result && times < maxMatchTimes)
      // add result
      func({match, filepath, count})
    } else {
      func(null)
    }
  });
}

function getLinePos (con) {
  let result = []
  con.replace(/\n/g, function (a, index) {
    result.push(index)
  })
  if (!result.length) {
    result.push(con)
  }
  return result
}

function mapLineByNumber (result, index) {
  if (result.length <= 1) {
    return 1
  }
  return _mapLineByNumber(result, 0, result.length-1, index) + 1
}
    
function _mapLineByNumber (result, start, end, index) {
  let middle = Math.floor((start + end) / 2)
  if (start === middle && (start + 1 === end)) {
    return index > result[middle] ? end : start
  } else if (result[middle] === index) {
    return middle
  } else if (result[middle] > index) {
    return _mapLineByNumber(result, start, middle, index)
  } else {
    return _mapLineByNumber(result, middle, end, index)
  }
}
// exports
module.exports = {find:find,replace:replace};