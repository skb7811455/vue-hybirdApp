let fs = require('fs')
let path = require('path')
let stacks = []
let marks = {}
const maxLimit = 20

function find (filepath, func) {
  let cb = function () {
    let keys = Object.keys(marks)
    if (keys.length === 0) {
      func({data: stacks})
      func({EOF:true})
      stacks = []
    } else if (stacks.length >= maxLimit) {
      func({data: stacks.splice(0, maxLimit)})
    }
  }
  _search(filepath, cb)
}

function _search (filepath, cb) {
  if (!marks[filepath]) {
    marks[filepath] = 1
  }
  fs.readdir(filepath, function (error, files) {
    if (!error) {
      let filename
      let newPath
      let stat
      for (let i = 0, len = files.length; i < len; i++) {
    		filename = files[i]
    		newPath = path.join(filepath, filename)
    		stat = fs.statSync(newPath)
    		//if it's the directory
        if (stat.isDirectory()) {
          if (!/node_modules/.test(newPath) && filename[0] !== '.') {
            _search(newPath, cb)
          }
        } else {
          stacks.push({filepath: newPath, name: filename})
        }
    	}
    }
    delete marks[filepath]
  	cb()
  });
}

// exports
module.exports = {find:find};