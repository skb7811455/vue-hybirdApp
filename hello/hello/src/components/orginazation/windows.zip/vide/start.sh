#!/bin/sh
path=$1
first=${path:0:1}
realpath=`ls -al $0`
realpath=`dirname ${realpath##*->}`
if [ "$first" == "." ]
then
pwd=`pwd`
path=${path:1}
path="$pwd$path"
fi
`${realpath}/vide.app/Contents/MacOS/nwjs ${path}`
